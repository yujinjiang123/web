<template>
  <div>
    <Avatar src="https://i.loli.net/2017/08/21/599a521472424.jpg"></Avatar>
  </div>
</template>
<script>
  export default {};
</script>
